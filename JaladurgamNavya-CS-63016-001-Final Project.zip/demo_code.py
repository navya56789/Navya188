import tkinter as tk
from tkinter import ttk
from tkinter import filedialog
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, r2_score
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX
from keras.models import Sequential
from keras.layers import LSTM, Dense
from pandas.plotting import autocorrelation_plot
from statsmodels.tsa.stattools import adfuller
from pmdarima import auto_arima

class YourClassName:

    def adfuller_test(self, data):
        result = adfuller(data)
        return result[1]

    def class1(self, test):
        hh = self.adfuller_test(test)
        if hh < 0.05:
            print("Data is stationary.")
            stepwise = auto_arima(test, trace=True, suppress_warnings=True, max_p=8, max_d=8, max_q=8, max_order=8)
            return stepwise
        else:
            print("Data is non-stationary.")
            data_diff = test - test.shift(1)
            hh_diff = self.adfuller_test(data_diff.dropna())
            if hh_diff < 0.05:
                print("Data after differencing is stationary.")
                stepwise = auto_arima(test, trace=True, suppress_warnings=True, max_p=8, max_d=8, max_q=8, max_order=8)
                return stepwise

# loading dataset from file
def load_dataset():
    file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
    if file_path:
        dataframe = pd.read_csv(file_path)
        # converting 'Date' column to datetime format and set it as index
        dataframe['Date'] = pd.to_datetime(dataframe['Date'])
        dataframe.set_index('Date', inplace=True)
        return dataframe
    else:
        return None

# splitting data into train and test sets
def split_data(dataframe):
    df=dataframe.reset_index()
    train_data = df[df['Date'].dt.year <= 2020]
    test_data = df[df['Date'].dt.year > 2020]
    return train_data, test_data

# calculating ARIMA predictions and metrics
def get_arima_predictions(train_data, test_data, order):
    model = ARIMA(train_data['Open'], order=order)
    model_fit = model.fit(cov_type="opg")
    predictions = model_fit.forecast(steps=len(test_data))
    
    mse = mean_squared_error(test_data['Open'], predictions)
    rmse = np.sqrt(mse)
    r_squared = r2_score(test_data['Open'], predictions)
    n = len(test_data)
    p = 1
    adjusted_r_squared = 1 - (1 - r_squared) * ((n - 1) / (n - p - 1))
    
    return predictions, mse, rmse, r_squared, adjusted_r_squared

def get_sarima_predictions(train_data, test_data, order):
    model = SARIMAX(train_data['Open'], order=order)
    model_fit = model.fit()
    prediction_sarima = model_fit.forecast(steps=len(test_data)) 
    
    mse = mean_squared_error(test_data['Open'], prediction_sarima)  
    rmse = np.sqrt(mse)
    r_squared = r2_score(test_data['Open'], prediction_sarima)
    n = len(test_data)
    p = 1
    adjusted_r_squared = 1 - (1 - r_squared) * ((n - 1) / (n - p - 1))
    
    return prediction_sarima, mse, rmse, r_squared, adjusted_r_squared


#  calculating LSTM predictions and metrics
def get_lstm_predictions(train_data, test_data, X_train, y_train, X_test, scaler):
    model_lstm = Sequential()
    model_lstm.add(LSTM(units=50, input_shape=(X_train.shape[1], X_train.shape[2])))
    model_lstm.add(Dense(units=1))
    model_lstm.compile(optimizer='adam', loss='mean_squared_error')
    model_lstm.fit(X_train, y_train, epochs=50, batch_size=1, verbose=0)
    
    predictions_lstm = model_lstm.predict(X_test)
    predictions_lstm = scaler.inverse_transform(predictions_lstm)
    
    mse = mean_squared_error(test_data['Open'].values, predictions_lstm)
    rmse = np.sqrt(mse)
    r_squared = r2_score(test_data['Open'], predictions_lstm)
    n = len(test_data)
    p = 1
    adjusted_r_squared = 1 - (1 - r_squared) * ((n - 1) / (n - p - 1))
    
    return predictions_lstm, mse, rmse, r_squared, adjusted_r_squared

# plot predictions and test data
def plot_predictions(predictions, test_data):
    plt.figure(figsize=(10, 5))
    plt.plot(test_data['Open'].values, label='Test Data')
    plt.plot(predictions, label='Predictions')
    plt.xlabel('Date')
    plt.ylabel('Open Price')
    plt.title('Predictions vs. Test Data')
    plt.legend()
    
    canvas = FigureCanvasTkAgg(plt.gcf(), master=window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)


def on_predict_click():
    dataframe = load_dataset()
    if dataframe is not None:
        train_data, test_data = split_data(dataframe)
        
        # Setting index
        train_data.set_index("Date", inplace=True)
        test_data.set_index("Date", inplace=True)
        
        # Autocorrelation plot
        plt.figure(figsize=(10, 5))
        autocorrelation_plot(train_data['Open'])
        plt.title('Autocorrelation Plot')
        plt.show()
        
        your_object = YourClassName()
        result = your_object.class1(train_data['Open'])
        order = result.order
        
        # ARIMA
        arima_predictions, arima_mse, arima_rmse, arima_r_squared, arima_adjusted_r_squared = get_arima_predictions(train_data, test_data, order)
        
        # SARIMA
        sarima_predictions, sarima_mse, sarima_rmse, sarima_r_squared, sarima_adjusted_r_squared = get_sarima_predictions(train_data, test_data, order)
        
        # LSTM
        combined_data = pd.concat([train_data['Open'], test_data['Open']], axis=0)
        scaler = MinMaxScaler(feature_range=(0, 1))
        scaled_data = scaler.fit_transform(combined_data.values.reshape(-1, 1))
        
        time_steps = 1
        X_train, y_train = [], []
        for i in range(len(train_data) - time_steps):
            X_train.append(scaled_data[i:(i + time_steps), 0])
            y_train.append(scaled_data[i + time_steps, 0])
        X_train, y_train = np.array(X_train), np.array(y_train)
        X_train = np.reshape(X_train, (X_train.shape[0], 1, X_train.shape[1]))

        inputs = scaled_data[len(train_data) - time_steps:]
        inputs = inputs.reshape(-1, 1)
        X_test, y_test = [], []
        for i in range(len(inputs) - time_steps):
            X_test.append(inputs[i:(i + time_steps), 0])
            y_test.append(inputs[i + time_steps, 0])
        X_test, y_test = np.array(X_test), np.array(y_test)
        X_test = np.reshape(X_test, (X_test.shape[0], 1, X_test.shape[1]))
        
        lstm_predictions, lstm_mse, lstm_rmse, lstm_r_squared, lstm_adjusted_r_squared = get_lstm_predictions(train_data, test_data, X_train, y_train, X_test, scaler)
        
        # Displaying Predictions and Metrics
        results_text = "ARIMA Metrics:\n"
        results_text += f"MSE: {arima_mse}\n"
        results_text += f"RMSE: {arima_rmse}\n"
        results_text += f"R-squared: {arima_r_squared}\n"
        results_text += f"Adjusted R-squared: {arima_adjusted_r_squared}\n\n"

        results_text += "SARIMA Metrics:\n"
        results_text += f"MSE: {sarima_mse}\n"
        results_text += f"RMSE: {sarima_rmse}\n"
        results_text += f"R-squared: {sarima_r_squared}\n"
        results_text += f"Adjusted R-squared: {sarima_adjusted_r_squared}\n\n"

        results_text += "LSTM Metrics:\n"
        results_text += f"MSE: {lstm_mse}\n"
        results_text += f"RMSE: {lstm_rmse}\n"
        results_text += f"R-squared: {lstm_r_squared}\n"
        results_text += f"Adjusted R-squared: {lstm_adjusted_r_squared}\n\n"

        # # Plotting Predictions
        # plt.figure(figsize=(12, 8))

        # plt.subplot(3, 1, 1)
        # plot_predictions(arima_predictions, test_data)
        # plt.title('ARIMA Predictions')

        # plt.subplot(3, 1, 2)
        # plot_predictions(sarima_predictions, test_data)
        # plt.title('SARIMA Predictions')

        # plt.subplot(3, 1, 3)
        # plot_predictions(lstm_predictions, test_data)
        # plt.title('LSTM Predictions')

        # plt.tight_layout()

        # Update GUI with results
        result_label.config(text=results_text)

# Creating the main window
window = tk.Tk()
window.title("Stock Price Prediction")


header_label = ttk.Label(window, text="Stock Price Prediction and Analysis", font=("Helvetica", 18, "bold"))
header_label.pack(pady=10)


load_button = ttk.Button(window, text="Load Dataset", command=on_predict_click)
load_button.pack()


result_label = ttk.Label(window, text="")
result_label.pack()

window.mainloop()


